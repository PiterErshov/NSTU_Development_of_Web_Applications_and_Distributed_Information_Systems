﻿var dgram = require('dgram'); //Модуль dgram обеспечивает реализацию сокетов UDP датаграмм
const fs = require("fs");//модуль для работы с файлом
var dgramSocket = dgram.createSocket("udp4"); //Для UDP-сокетов заставляет dgram.Socket прослушивать сообщения дейтаграммы на именованном порту
var crypto = require('crypto'); // crypto - модуль шифрования. Подключаю его для создания хеша
var readline = require('readline');// Предоставляет интерфейс для чтения данных из читаемого потока по одной строке за раз
var msg_size = 1; // Количество байт под тип сообщения
var msg_length_size = 2; // Количество байт под длину сообщения
var interval = 2000; // Каждые 2 секунды запрос
var port = 1024; // Номер порта
var readline = readline.createInterface(process.stdin, process.stdout, null); // Для считывания текста с консоли
var onlineUser = []; // Массив со всеми пользователями онлайн
var allHesh = []; // Массив со всеми хэшами от файла
var alladdr = []; // Массив со всеми адресами
var allId = []; // Массив с id (хэшами) от соседей
var n_hesh = [];//Массив с хэшами от файлов от соседей
var userName; // имя пользователя
var userId;// хэш пользователя
var flag = false; // Флаг дял онлайн\оффлайн пользователя
var ip_addr = '255.255.255.255'; // Адрес, с которого отправляется запрос
var hesh_file = '';//хэш от содержимого файла
var home_ip = '';//ip пользователя
var request = 0; // Запрос
var response = 1; // Ответ
var mess = 2; // Сообщение с хэшем
// Определяем ip адрес компьютера. К Первым 3-м цифрам ip добавляем 255 (широковещательный)
require('dns').lookup(require('os').hostname(), function (err, add, fam)
{
    for (var i = 0; i < add.length; i++)
        home_ip += add[i];
})

// Сокет начал прослушивание

dgramSocket.on('listening', function ()
{
    var ServerAddress = dgramSocket.address();
    console.log('Listening ' + ServerAddress.address + ":" + ServerAddress.port);
});

// Сокет создан
dgramSocket.bind(port, function ()
{
    dgramSocket.setBroadcast(true);
    console.log('Broadcast on.');

    readline.question('Your name: ', (name) => {
        readline.question('Name of file: ', (info) => {
            
            // Заношу информацию об имени и закрываю входной поток
            userName = name;
            readline.close();
            let data = fs.readFileSync(info + ".txt", "utf8");
            var lineReader = require('readline').createInterface({
                input: require('fs').createReadStream(info + ".txt")
            });

            var line = '';
            //var inform = '';
            lineReader.on('line', function (line) {
                console.log('Line from file:', line);
                //inform += line;
            });
            // Заношу информацию об имени пользователя
            user_name = crypto.createHash('md5').update(info).digest(); // name (присваиваю хеш md5)

            //Заношу информацию о пользователе
            hesh_file = crypto.createHash('md5').update(line).digest(); // line (присваиваю хеш md5)
           
            //Помещаю хэши в массив для работы с ними.
            allHesh.push(user_name);
            allHesh.push(hesh_file);
            /*
            var test=['1', '2', '3'];
            console.log(test);
            test.splice(1, 1);
            console.log(test);
            */
            // Заношу информацию об id пользователя
            userId = crypto.createHash('md5').update(home_ip).digest(); // id (присваиваю хеш md5)
            loopFunction();    // Предварительно вызываем, чтобы не ждать интервального времени перед первым вызовом
            setInterval(loopFunction, interval);  // Задаём периодичность выполнения для функции 
        });
    });
});
// ищет минимум в массиве и возвращает его индекс
function arrayMin(arr)
{
    var len = arr.length, min = Infinity;
    var cr;
    while (len--) 
    {
        if (arr[len] < min) 
        {
            min = arr[len];
            cr = len;
        }
    }
    return cr;
};
//провит операцию XOR с битами хэша
function metric(hash1, hash2)
{ 
    let ret = Buffer.from(hash1) 
    for (let i =0;i<hash1.length;i++) 
        ret[i]^=hash2[i] 
    return ret 
} 

function find(arr, elem)
{
    var len = arr.length;
    var fl = false;
    while (len--)
    {
        if (arr[len] == elem)
        {   
            fl = true;
            break;
        }
    }
    return fl;
};

//Проверяет есть ли элемент в массиве возвращая 1 - да и  0 - нет
function find_hesh(arr, elem)
{
    var len = arr.length;
    var fl = false;
    while (len--)
    {
        var bf = arr[len];
        if ( roughScale(bf.toString("hex"), 16).toString() == roughScale(elem.toString("hex"), 16).toString())
        {   
            fl = true;
            break;
        }
    }
    return fl;
};
//переводит хэш в 10-е значение (для поиска минимума)
function roughScale(x, base)
{
    var parsed = parseInt(x, base);
    if (isNaN(parsed)) { return 0 }
        return parsed;
}
     
// Сокет получил сообщение
dgramSocket.on('message', function (msg, rinfo) {

    //Если не введено имя
    if (userName === undefined)

        return

    var msgType = msg[0]; // Определяем тип сообщения

    // Для запроса. Формируем дейтаграмму
    if (msgType === request)
    {
        var rmsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + userId.length); // Собираем сообщение, чтоб ответить
        rmsg[0] = response;
        rmsg.fill(userId, msg_size, msg_size + userId.length)
        rmsg.writeUInt16BE(Buffer.byteLength(userName),msg_size + userId.length );        
        rmsg.fill(userName, msg_size + userId.length + msg_length_size ); // + name
        dgramSocket.send(rmsg, 0, rmsg.length, rinfo.port, rinfo.address);
    }
    //Для расшифровки
    if (msgType === response)
    {
        var msgLength; //длина сообщения
        msgLength = msg.readUInt16BE(msg_size + userId.length);       
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        var id = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        var msg_addr = rinfo.address;
        var msg_port = rinfo.port;
        var flag = 0;
        if(msg_addr != home_ip)
        {
        // заносим ip в массив (кроме домашнего, для проверки работоспособности убрать второре условие)
        if(find(alladdr, msg_addr) == false)
        {   
            alladdr.push(msg_addr);
            //console.log(msg_addr);
        }
        // заносим id в массив (кроме домашнего, для проверки работоспособности убрать второре условие)
        if(find_hesh(allId, id) == false)
            allId.push(id);       
        }
        onlineUser.push(msgText + " " + id.toString('hex') + ": " + msg_addr); // Добавляем онлайн пользователя в массив
    }
    //Если в сообщении есть хэш от файла
    if (mess === msgType)
    {
       var msgLength; //длина сообщения
       msgLength = msg.readUInt16BE(msg_size + userId.length);       
       var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
       var id = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
       var msg_addr = rinfo.address;
       var flag = 0;
       if(msg_addr != '127.0.0.1')
       n_hesh.push(msgText + " " + id.toString('hex') + " " + msg_addr.toString()); // Добавляем онлайн пользователя в массив
    }
});


function loopFunction()
{       
    // Если не подключились, пропускаем этап вывода на экран информации об online пользователях
    // Подключение в данном случае - первый вызов этой функции
   
    if (flag === true)
    {
        // Выводим информацию об online пользователях, которую сформировали с предыдущей рассылки
        console.log("Online:");

        // Очищаем массив с информацией от соседей
        while (onlineUser.length)
            console.log(onlineUser.pop());
        
        console.log("\n");

        console.log("Hesh:");
        // Очищаем массив с хэшами от файлов от соседей
        while (n_hesh.length)
        {
            fs.appendFileSync("data.txt", "||" + n_hesh[n_hesh.length - 1] + "|| \n", "UTF-8");
            console.log(n_hesh.pop());
        }
    }
    else
    {
        console.log("Connection...");
        flag = true;
    }

    console.log("Request...");
    checkOnline(); // Запрос на проверку онлайн-пользователей

    //весь бред ниже нужен для поиска адреса, на который нужно отослать хэш от файла
    //сначала берём один из хэшей от файла.
    //затем, с помощю массива с хэшами от соседей (id) и хэша от файла создаём новый массив через опреацию XOR
    //полученный массив переводим в 10 систему
    //в 10-м массиве ищем индес минимального элемента - это индекс в массиве со всеми ip соседей
    //заносим найденный индекс в массив-карту, который нужен для отправки хэшей по адресам
    //в массиве-карте номер элемента массива это номер хэша от файла, а число в элементе массива это индекс в массиве ip
    //console.log(alladdr);
    if(alladdr.length != 0)
    {
        var i = 0;
        var send_map = []; // Массив со всеми номерами элементов allHesh, alladdr, allport для сборки сообщений с хэшами
        send_map.length = allHesh.length;
        while( i < allHesh.length)
        {        
            var buffID = [];
            var j = 0;
            //console.log(allId.length);
            while(j < allId.length)
            {
                buffID[j] = metric(allId[j], allHesh[i]);
                // console.log("mtr", metric(allId[j], allHesh[i]));
                j++;
            }

            var find_buff = [];     
            find_buff.length = allId.length;

            j = 0;
            while(j < allId.length)
            {            
                find_buff[j] =  roughScale(buffID[j].toString("hex"), 16).toString();
                j++;
            }
            //console.log(buffID);
            send_map[i] = arrayMin(find_buff);
            i++;
        }
        //console.log(send_map);
        for(var k = 0; k < send_map.length; k++)
        {
            send_hesh(alladdr[send_map[k]], k); // хэш под номером k отправляем по адресу под номеров send_map[k]
            alladdr.splice(send_map[k],send_map[k]);
            if(allId.length > 1)
                allId.splice(send_map[k],send_map[k]);
        }
        console.log("\n");
    }
}

function send_hesh(ip, index)
{
    var rmsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + allHesh[index].length); // Собираем сообщение, чтоб ппослать хэш
    rmsg[0] = mess;
    rmsg.fill(allHesh[index], msg_size, msg_size + allHesh[index].length)
    rmsg.writeUInt16BE(Buffer.byteLength(allHesh[index]),msg_size + allHesh[index].length);
    rmsg.fill(userName, msg_size + userId.length + msg_length_size ); // + name
    dgramSocket.send(rmsg, 0, rmsg.length, port, ip);
}
// Функция широковещательной рассылки

function checkOnline()
{
    var requestMsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + userId.length); // Формируем сообщение для проверки пользователей
    requestMsg[0] = request;
    requestMsg.fill(userId, msg_size, msg_size + userId.length)
    requestMsg.writeUInt16BE(Buffer.byteLength(userName),msg_size + userId.length );        
    requestMsg.fill(userName, msg_size + userId.length + msg_length_size ); // + name
    dgramSocket.send(requestMsg, 0, requestMsg.length, port, ip_addr);// Отсылаем запрос
}