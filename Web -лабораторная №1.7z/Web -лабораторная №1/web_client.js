const dgram = require('dgram'); //Модуль dgram обеспечивает реализацию сокетов UDP датаграмм 
const readline = require('readline');// Доступ к модулю readline (предоставляет интерфейс для чтения данных из читаемого потока (например, process.stdin) по одной строке за раз) 
const MSG_TYPE_SIZE = 1; // Количество байт под тип сообщения 
const MSG_LENGTH_SIZE = 2; // Количество байт под длину сообщения 
const MSG_REQUEST_CODE = 0; // Запрос 
const MSG_RESPONSE_CODE = 1; // Ответ 
const PORT = 1111; //номер порта 
var BROADCAST_ADDRESS = '255.255.255.255'; // Адрес, с которого отправляется запрос (127.0.0.1 - loop) 
const CHECK_INTERVAL = 1000; //Каждую секунду происходит запрос 
const dgramSocket = dgram.createSocket("udp4"); //Для UDP-сокетов заставляет dgram.Socket прослушивать сообщения дейтаграммы на именованном порту 
const rl = readline.createInterface // Для считывания текста с консоли 
    ({
        input: process.stdin,
        output: process.stdout
    });
var onlineUserInfo = []; // Массив со всеми пользователями онлайн 
var userName;
var userId;
var isConnected = false; // Флаг - пользователь подключен (1-ый раз получаем инфу о пользователях в сети) 
/*require('dns').lookup(require('os').hostname(), function (err, add, fam) { 
var c = 0; 
var str = ''; 
for(var i = 0; i < add.length; i++) 
{ 
if(c !=3) 
{ 
str +=add[i]; 
} 
if(add[i] == '.') 
c++; 
} 
str += '255'; 
//console.log('addr: '+str); 
BROADCAST_ADDRESS = str; 
}) */
dgramSocket.on('listening', function () {
    var serverAddress = dgramSocket.address();
    console.log('Слушаем ' + serverAddress.address + ":" + serverAddress.port);
}); // Сокет начал прослушивание 

dgramSocket.on('message', function (msg, rinfo) { // Сокет получил сообщение 
    if (userName === undefined) {
        return
    } // Всех пользователей анонимов (не ввел имя) - игнорировать сообщения!!! (опять Миша всех игнорит) 

    var msgType = msg[0]; // Определяем тип сообщения 

    if (msgType === MSG_REQUEST_CODE) { // Когда пришел запрос 

        var responseMsg = Buffer.allocUnsafe(MSG_TYPE_SIZE + MSG_LENGTH_SIZE + userName.length + (userId.toString()).length + 1); // Собираем сообщение, чтоб ответить 
        responseMsg[0] = MSG_RESPONSE_CODE; // если единица в первом байте, то это ответ 
        var length = userName.length + (userId.toString()).length + 1; // размер сообщения хранится в 2 байта  
        responseMsg[MSG_TYPE_SIZE + MSG_LENGTH_SIZE - 1] = length;
        length = length >> 8;
        responseMsg[MSG_TYPE_SIZE + MSG_LENGTH_SIZE - 2] = length;
        responseMsg.fill(userName, MSG_TYPE_SIZE + MSG_LENGTH_SIZE, MSG_TYPE_SIZE + MSG_LENGTH_SIZE + userName.length); // + name 
        responseMsg[MSG_TYPE_SIZE + MSG_LENGTH_SIZE + userName.length] = '-'.charCodeAt(0); // + разделитель между name и id | 
        responseMsg.fill(userId.toString(), MSG_TYPE_SIZE + MSG_LENGTH_SIZE + userName.length + 1); // + id 
        //console.log(responseMsg); 
        // Посылаем ответ указанный отправителем адрес 
        dgramSocket.send(responseMsg, 0, responseMsg.length, rinfo.port, rinfo.address);
    }
    // Если пришёл ответ на запрос 
    else if (msgType === MSG_RESPONSE_CODE) {
        var msgLength; //длина сообщения 
        msgLength = msg[MSG_TYPE_SIZE + MSG_LENGTH_SIZE - 2]; // Распаковываем размер сообщения 
        msgLength = msgLength << 8; //Сдвигает двоичное представление чисел (длины) на 8 разрядов влево, заполняя освободившиеся справа разряды нулями 
        msgLength = msgLength | msg[MSG_TYPE_SIZE + MSG_LENGTH_SIZE - 1]; // | Возвращает 1 в тех разрядах, которые хотя бы у одного из операндов были равны 1. 

        var msgText = msg.toString('utf-8', MSG_TYPE_SIZE + MSG_LENGTH_SIZE); // Извлекаем текст сообщения 
        onlineUserInfo.push(msgText); // Добавляем онлайн пользователя в массив 
    }
});

rl.question('Пожалуйста, введите сообщение: ', (isid) => { // Просим ввести сообщение
    userId = isid; // После ввода сообщения
    dgramSocket.bind(PORT, function () { // Когда сокет создан 
        console.log('Связанный сокет');
        dgramSocket.setBroadcast(true);//включение широковещательной рассылки 
        rl.question('Пожалуйста, введите ваше имя: ', (name) => { // Просим ввести имя пользователя 
            userName = name; // После ввода имени 
            rl.close();
            // id (у него var, че присвоишь, то и будет, хочется поразвлекаться? ставь Date.now() - кол-во мс, прошедших с1 января 1970 г.). 
            loopFunction(); // Предварительно вызываем, чтобы не ждать интервального времени перед первым вызовом //АААААААААААААААААААААААААААААА 
            setInterval(loopFunction, CHECK_INTERVAL); // Задаём периодичность выполнения для функции 
        });
    });
});

function loopFunction() {
    // Функция, которая выполняется каждые CHECK_INTERVAL мс //АААААААААААААААААААААААААААААА зачем 
    // Если не подключились, пропускаем этап вывода на экран информации об online пользователях 
    // Подключение в данном случае - первый вызов этой функции 
    if (isConnected === true) { // Выводим информацию об online пользователях, которую сформировали с предыдущей рассылки 
        {
            console.log("В сети находятся:");


        }
        while (onlineUserInfo.length) {
            // Очищаем массив для дальнейшего заполнения новой инфой 
            console.log(onlineUserInfo.pop());
        }
    }
    else {
        console.log("Устанавливаем соединение. Подождите :)");
        isConnected = true;
    }

    checkOnline(); // Запрос на проверку онлайн-пользователей: кто здесь ? 
}
function checkOnline() { // Функця для широковещательной рассылки 
    var requestMsg = Buffer.allocUnsafe(MSG_TYPE_SIZE); // Формируем сообщение для проверки пользователей 
    requestMsg[0] = MSG_REQUEST_CODE; // 0 в бервом байте - запрос 
    dgramSocket.send(requestMsg, 0, requestMsg.length, PORT, BROADCAST_ADDRESS); // Отсылаем запрос 
}