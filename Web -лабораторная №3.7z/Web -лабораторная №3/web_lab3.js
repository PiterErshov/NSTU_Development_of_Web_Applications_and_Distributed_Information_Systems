﻿var dgram = require('dgram'); //Модуль dgram обеспечивает реализацию сокетов UDP датаграмм
const fs = require("fs");//модуль для работы с файлом
//const vr =  require('./vars');
var dgramSocket = dgram.createSocket("udp4"); //Для UDP-сокетов заставляет dgram.Socket прослушивать сообщения дейтаграммы на именованном порту
var crypto = require('crypto'); // crypto - модуль шифрования. Подключаю его для создания хеша
var readline = require('readline');// Предоставляет интерфейс для чтения данных из читаемого потока по одной строке за раз
var msg_size = 1; // Количество байт под тип сообщения
var msg_length_size = 2; // Количество байт под длину сообщения
var interval = 2000; // Каждые 2 секунды запрос
var port = 1024; // Номер порта
var readline = readline.createInterface(process.stdin, process.stdout, null); // Для считывания текста с консоли
var onlineUser = []; // Массив со всеми пользователями онлайн
var allHesh = []; // Массив со всеми хэшами от файла
var alladdr = []; // Массив со всеми адресами
var allId = []; // Массив с id (хэшами) от соседей
var n_hesh = [];//Массив с хэшами от файлов от соседей
var h_ip = [];//Массив с IP для хэшей от файлов от соседей
var us_h = [];//массив (да, ещё один) для имён соседей
var userName; // имя пользователя
var userId;// хэш пользователя
var flag = false; // Флаг дял онлайн\оффлайн пользователя
var ip_addr = '255.255.255.255'; // Адрес, с которого отправляется запрос
var hesh_file = '';//хэш от содержимого файла
var home_ip = '';//ip пользователя
//ТИПЫ СООБЩЕНИЙ
var request = 0; // Запрос
var response = 1; // Ответ
var mess = 2; // Сообщение с хэшем
var ques = 3; //сообщение с запросом на поиск файла, если узел хранит файл, то отправить сообщение типа f_hash по адресу отправки ques
var hash_ip = 4; //ответ на сообщение типа ques с IP адресом отправленного в ques хэша
var no_hash = 5;//отрицательный ответ на сообщение типа ques с IP адресами двух ближайших узлов сети, где может быть искомый хэш
var f_hash = 6;//ответ на запрос типа ques, с хэшем от содержимого файла (В структуре типа HESH обозначен как H)
var take_f = 7;//запрос на получение файла по его хэшу
var ff = 8;//ответ на take_f с содержимым файла
//КУЧА ФЛАГОВ (ПРОСТИТЕ МЕНЯ ЗА ЭТО)
var fl_q = false;//флаг, сообщающий о приходе сообщения
var fl_IP = true;//флаг, сообщающий о приходе IP адреса
var fl_H = false;//флаг, сообщающий о приходе хэша от содержимого файла
var fl_TH = false;//флаг, сообщающий о приходе хэша от содержимого файла в сообщении-запросе на выдачу содержимого файла
var fl_f = false;//флаг, сообщающий о приходе содержимого файла (сам файл, по сути)
var q_hesh; // хэш от имени файла, который пришёл от узла, который ищет файл
var q_IP; //IP адрес q_hesh (нужен для обратного ответа) 
var H_IP;//IP адрес q_hesh (ВВЕДЁН, ЧТОБЫ НЕ ЗАПУТАЛАСЬ ПРОГРАММА, ТАК КАК ПОКА МЫ ИЩЕМ ОДИН ФАЙЛ, МОЖЕТ ПРИЙТИ ЗАПРОС НА ДРУГОЙ) 
var TH_IP;//IP адрес q_hesh (ВВЕДЁН, ЧТОБЫ НЕ ЗАПУТАЛАСЬ ПРОГРАММА, ТАК КАК ПОКА МЫ ИЩЕМ ОДИН ФАЙЛ, МОЖЕТ ПРИЙТИ ЗАПРОС НА ДРУГОЙ) 
var anyIP = []; //массив IP адресов, которые пришли от улза, у которого нет никакой информации об искомом файле (ПО ХОРШЕМУ ЭТО ДОЛЖНО БЫТЬ, НО Я ЛЕНИВЫЙ ЗАСРАНЕЦ)
var IP; //IP адрес узла, с которо пришёл хэш от искомого файла (имеется любой хэш от имени файла)
var H; //хэш от содержимого искомого файла (нужет, чтобы послать запрос на получение содержимого файла по хэшу)
var TH; //хэш от содержимого искомого файла, которйы пришёл в сообщении-запросе на выдачу файла
var COM_F; //содержимое файла (будет помещено в созданный файл)
var HESH_M = [];//массив структур типа HESH, нужен, чтобы поставить в соответствие хэшам от имени файла (от слов в имени, от имени целиком, от имени с расширением файла) хэш от содержимого этого файла
var name_of_file;
var nh;
var nm;
var SEND_FLAG = false;
function HESH(h_n, H, file) {
    this.h_n = h_n;//массив хэшей от имён файла (от слов в. имени, от имени целиком, от имени с расширением файла)
    this.H = H;//хэш от содержимого файла
    this.file = file;//полное имя файла с расширением (необходимо, чтобы вернуть содержимое файла узлу, который файл ищет)
}

// Определяем ip адрес компьютера. К Первым 3-м цифрам ip добавляем 255 (широковещательный)
require('dns').lookup(require('os').hostname(), function (err, add, fam) {
    for (var i = 0; i < add.length; i++)
        home_ip += add[i];
})

// Сокет начал прослушивание

dgramSocket.on('listening', function () {
    var ServerAddress = dgramSocket.address();
    console.log('Listening ' + ServerAddress.address + ":" + ServerAddress.port);
});

// Сокет создан
dgramSocket.bind(port, function () {
    dgramSocket.setBroadcast(true);
    console.log('Broadcast on.');

    readline.question('Your name: ', (name) => {
        readline.question('Name of file: ', (info) => {

            // Заношу информацию об имени и закрываю входной поток
            userName = name;
            readline.close();
            readline.close();

            let p = 0;
            let f_n = [];
            fs.readdirSync('./files/').forEach(file => {
                if (file != 'data.txt')
                    f_n.push(file);
            });
            p = 0;
            while (p < f_n.length) {
                let fr = fs.readFileSync('./files/' + f_n[p], 'utf8');
                let sb = f_n[p].split('.')[0].split(' ');
                //console.log( sb);
                let p1 = 0
                let h = []
                while (p1 < sb.length) {
                    h.push(crypto.createHash('md5').update(sb[p1]).digest())
                    p1++;
                }
                if (find_hesh(h, crypto.createHash('md5').update(f_n[p].split('.')[0]).digest())[0] == false)
                    h.push(crypto.createHash('md5').update(f_n[p].split('.')[0]).digest());
                h.push(crypto.createHash('md5').update(f_n[p]).digest());
                let HH = new HESH(h, crypto.createHash('md5').update(fr).digest(), f_n[p]);
                HESH_M.push(HH);
                p++;
            }
            p = 0;
			//console.log(HESH_M);
            //*
            while (p < HESH_M.length) {
                let u = 0;
                while (u < HESH_M[p].h_n.length) {
                    allHesh.push(HESH_M[p].h_n[u]);
                    u++;
                }
                allHesh.push(HESH_M[p].H);
                p++;
            }
            //*/ 
            //А ТУТ МЫ ШЛЁМ ВСЕМ СОСЕДЯМ ЗАПРОС НА ПОИСК ФАЙЛА
            name_of_file = info;
            //ВНИМАНИЕ! ТЕСТОВЫЙ ПРОГОН НА ОДНОМ КОМПЬЮТЕРЕ. ДЛЯ ПЕРЕКЛЮЧЕНИЯ В СЕТЕВОЙ РЕЖИМ ЗАКОММЕНТИРУЙТЕЙ 3 СТРОКИ НИЖЕ
           //name_of_file = 'test';
           // nh = crypto.createHash('md5').update(name_of_file).digest();
           // u_send(nh, home_ip, ques);
            //*
            userId = crypto.createHash('md5').update(home_ip).digest(); // id (присваиваю хеш md5)

           
            //*/
            loopFunction();    // Предварительно вызываем, чтобы не ждать интервального времени перед первым вызовом
           
            setInterval(loopFunction, interval);  // Задаём периодичность выполнения для функции 
            
        });
    });
});


// ищет минимум в массиве и возвращает его индекс.
function arrayMin(arr) {
    var len = arr.length, min = Infinity;
    var cr;
    while (len--) {
        if (arr[len] < min) {
            min = arr[len];
            cr = len;
        }
    }
    return cr;
};
//провит операцию XOR с битами хэша.
function metric(hash1, hash2) {
    let ret = Buffer.from(hash1)
    for (let i = 0; i < hash1.length; i++)
        ret[i] ^= hash2[i]
    return ret
}

function find(arr, elem) {
    var len = arr.length;
    var fl = false;
    while (len--) {
        if (arr[len] == elem) {
            fl = true;
            break;
        }
    }
    return fl;
};

//Проверяет есть ли элемент в массиве возвращая 1 - да и  0 - нет.
function find_hesh(arr, elem) {
    var len = arr.length;
    var fl = [];
    fl[0] = false;
    while (len--) {
        var bf = arr[len];
        if (roughScale(bf.toString("hex"), 16).toString() == roughScale(elem.toString("hex"), 16).toString()) {
            fl[0] = true;
            fl[1] = len;
            break;
        }
    }
    return fl;
};
//переводит хэш в 10-е значение (для поиска минимума).
function roughScale(x, base) {
    var parsed = parseInt(x, base);
    if (isNaN(parsed)) { return 0 }
    return parsed;
}

// Сокет получил сообщение.
dgramSocket.on('message', function (msg, rinfo) {

    //Если не введено имя.
    if (userName === undefined)
        return

    var msgType = msg[0]; // Определяем тип сообщения.

    // Для запроса. Формируем дейтаграмму.
    if (msgType === request) {
        var rmsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + userId.length); // Собираем сообщение, чтоб ответить.
        rmsg[0] = response;
        rmsg.fill(userId, msg_size, msg_size + userId.length)
        rmsg.writeUInt16BE(Buffer.byteLength(userName), msg_size + userId.length);
        rmsg.fill(userName, msg_size + userId.length + msg_length_size); // + name.
        dgramSocket.send(rmsg, 0, rmsg.length, rinfo.port, rinfo.address);
    }
    //Для расшифровки.
    if (msgType === response) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения.
        var id = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        var msg_addr = rinfo.address;
        var msg_port = rinfo.port;
        var flag = 0;
        if (msg_addr != home_ip) {
            // заносим ip в массив (кроме домашнего, для проверки работоспособности убрать второре условие).
            if (find(alladdr, msg_addr) == false) {
                alladdr.push(msg_addr);
                //console.log(msg_addr);
            }
            // заносим id в массив (кроме домашнего, для проверки работоспособности убрать второре условие).
            if (find_hesh(allId, id)[0] == false)
                allId.push(id);
        }
        onlineUser.push(msgText + " " + id.toString('hex') + ": " + msg_addr); // Добавляем онлайн пользователя в массив.
    }
    //Если в сообщении есть хэш от файла.
    if (msgType === mess) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        var id = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        //console.log(msg);
        var msg_addr = rinfo.address;
        var flag = 0;
        var bf = id;
        //console.log(bf);
        if (msg_addr != '127.0.0.1' && find(us_h, msgText) == false)
            us_h.push(msgText);// добавляетм имя соседа, пославшего хэш в массив имён

        if (msg_addr != '127.0.0.1' && find(h_ip, msg_addr.toString()) == false)
            h_ip.push(msg_addr.toString());// добавляем адрес соседа, пославшего хэш, в массив

        if (msg_addr != '127.0.0.1' && find(n_hesh, bf) == false)
            n_hesh.push(bf); // Добавляем хэш от соседа в массив.
    }
    //получен запрос на поиск файла, полученный хэш будет занесён в ques_hesh, для поска по всех хэшам (как своим, из массива HESH_M, так и по чужим, из массива n_hesh
    if (msgType === ques) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        q_hesh = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        q_IP = rinfo.address;
        console.log( 'СООБЩЕНИЕ', q_hesh.toString('hex'));
        fl_q = true;
    }
    //пришёл ответ с IP адресом местонахожения файла
    if (msgType === hash_ip) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        IP = Buffer.from(msg.slice(msg_size, msg_size + msg.length - 1 - msg_length_size));
        //console.log(IP.toString());
        IP = IP.toString().split(' ')[0];
        //console.log(IP);
        fl_IP == true;
    }
    //если файла на узле нет и нет хэша от его имени, то такой узел пошлёт в ответ IP адреса ближайших двух узлов, где могут быть хэши от имени файла
    if (msgType == no_hash) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        var id = Buffer.from(msg.slice(msg_size, msg_size + msg.length - 1 - msg_length_size));
        anyIP = id.toString();
        //console.log(anyIP);
    }
    //если файл на узле есть, то он отправит узлу, который послал запрос хэш от содержимого файла (в стурктуре HESH хранится в переменной H)
    if (msgType === f_hash) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        H = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        fl_H = true;
        H_IP = rinfo.address;
        //console.log(H);
    }
    //сообщение с хэшем от содержимого файла с запросом на отправку содержимого файла
    if (msgType === take_f) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        TH = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        TH_IP = rinfo.address;
        fl_TH = true;
    }
    //сообщение с содержимым файла
    if (msgType === take_f) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        TH = Buffer.from(msg.slice(msg_size, msg_size + userId.length));
        TH_IP = rinfo.address;
        fl_TH = true;
    }

    if (msgType === ff) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        var id = Buffer.from(msg.slice(msg_size, msg_size + msg.length - 1 - msg_length_size));
        
        COM_F = id;
        
        console.log(COM_F);
        fl_f = true;
    }

    if (msgType === 9) {
        var msgLength; //длина сообщения.
        msgLength = msg.readUInt16BE(msg_size + userId.length);
        var msgText = msg.toString('utf-8', msg_size + userId.length + msg_length_size); // Извлекаем текст сообщения
        var id = Buffer.from(msg.slice(msg_size, msg_size + msg.length - 2 - msg_length_size));
        
        nm = id
        console.log(nm);
       // fl_f = true;
    }
    
});


function loopFunction() {
    // Если не подключились, пропускаем этап вывода на экран информации об online пользователях.
    // Подключение в данном случае - первый вызов этой функции.
    //ЧТО ТУТ ПРОИСХОДИТ, ЕСЛИ В КРАТЦЕ
    //ПРОВЕРЯЕМ, ПРИШЁЛ ЛИ НАМ АДРЕС ГДЕ ЛЕЖИТ САМ ФАЙЛ 
    //ВНИМАНИЕ! ТЕСТОВЫЙ ПРОГОН НА ОДНОМ КОМПЬЮТЕРЕ. ДЛЯ ПЕРЕКЛЮЧЕНИЯ В СЕТЕВОЙ РЕЖИМ ЗАМЕНИТЕ home_ip НА q_IP

   // if(SEND_FLAG == false && )
    //{
        nh = crypto.createHash('md5').update(name_of_file).digest();
        let it = 0;
        while (it < alladdr.length) {
            u_send(nh, alladdr[it], ques);
            it++;
        }
     //   SEND_FLAG = true;
  //  }


    if (fl_IP == false) {//НЕТ НЕ ПРИШЁЛ, ТОГДА ПРОВЕРИМ, ПРИСЛАЛИ НАМ ЗВПРОС НАПОИСК ФАЙЛА
        if (fl_q == true) {//ДА, ПРИСЛАЛИ
            let i = 0;
            let f = [];
            let t = false;
            while (i < HESH_M.length) {//СНАЧАЛА ИЩЕМ В СВОИХ ХЭШАХ ИСКОМЫЙ, ВДРУГ У НАС ЕСТЬ НУЖНЫЙ ФАЙЛ
                let bh = HESH_M[i].h_n;
                if (find_hesh(bh, q_hesh)[0] == true) {
                    u_send(HESH_M[i].H, q_IP, f_hash);//q_IP - стандартный адрес, home_ip - тестовый
                    t = true;
                    break;
                }
                i++;
            }
            if (t == false) {//НЕ НАШЛИ У СЕБЯ ФАЙЛ, ИЩЕМ У СОСЕДЕЙ
                f = find_hesh(n_hesh, q_hesh)
                if (f[0] == true) {//НАШЛИ СОСЕДСКИЙ ХЭШ ОТ ИМЕНИ ФАЙЛА, СОПОСТАВИМ ЕГО С АДРЕСОМ С МАССИВЕ И ПОШЛЁМ НАЙДЕННЫЙ АДРЕС УЗЛУ, КОТОРЫЙ ИЩЕТ ФАЙЛ
                    u_send(h_ip[f[1]] + ' IP', q_IP, hash_ip);////q_IP - стандартный адрес, home_ip - тестовый
                }
                else {//НЕТ У НАС ИСКОМОГО ХЭША, ПОШЛЁМ В ОТВЕТ СОБЩЕНИЕ, ЧТО У НАС НЕТ НИ ФАЙЛА, НИ ССЫЛКИ НА НЕГО

                    u_send('I Have No Mouth, and I Must Scream', q_IP, no_hash);////q_IP - стандартный адрес, home_ip - тестовый
                    //send_test(home_ip, no_hash);

                    //console.log('Пришёл IP');

                }
            }
            fl_q = false;
        }
    }
    else {//А ТУТ НАМ ПРИШЁЛ АДРЕСС С КОТОРОГО ПРИШЛА ССЫЛКА НА ФАЙЛ, ПЕРЕШЛЁМ НАШ ЗАПРОС ЕМУ
        u_send(nh, IP, ques);
        fl_IP = false;
        //  console.log('Пошёл IP');
    }
    //ПРИШЁЛ НУЖНЫЙ НАМ ХЭШ ОТ ОСДЕРЖИМОГО ФАЙЛА (ДЕЛО В ТОМ, ЧТО РАБОТАЕТ У НАС ПОЛУЧЕНИЕ САМОГО ФАЙЛА (ЧИТАЙ ЕГО СОДЕРЖИМОГО) ТОЛЬКО ХЭШУ ОТ СОДЕРЖИМОГО. ПО ЭТО СНАЧАЛА ШЛЁМ УЗЛУ
    //КОТОРЫЙ ИЩЕТ ФАЙЛ ХЭШ ОТ СОДЕРЖИМОГО ФАЙЛА, УЗЕЛ ШЛЁТ ОБРАТНО ЭТО ХЭШ, НО В ДРУГОМ ТИПЕ СООБЩЕНИЯ, И ТОЛЬКО ПОЛУЧИВ НУЖНЫЙ ХЭШ ОТ СОДЕРЖИМОГО, ВЫСЫЛАЕТСЯ САМО СОДЕРЖИМОЕ
    if (fl_H == true) {
        u_send(H, H_IP, take_f);//ОТСЫЛАЕМ ЗАПРОС НА СОДЕРЖИМОЕ ФАЙЛА
        console.log('Пошёл хэш');
        fl_H = false;
    }
    //ПРИШЁЛ ХЭШ ОТ СОДЕРЖИМОГО В СООБЩЕНИИ С ЗАПРОСОМ НА СОДЕРЖИМОЕ
    if (fl_TH == true) {

        let buf = [];
        let i = 0;
        while (i < HESH_M.length) {
            buf.push(HESH_M[i].H);
            i++;
        }
        var bb;
        //console.log(buf);
        if (find_hesh(buf, TH)[0] == true) {//НАШЛИ НУЖНЫЙ НАМ ХЭШ, БЕРЁМ НАЗВАНИЕ ФАЙЛА И ЧИТАЕМ СОДЕРЖИМОЕ В ПЕРЕМЕННУЮ
            var fl = fs.readFileSync('./files/' + HESH_M[find_hesh(buf, TH)[1]].file, 'utf8');
            //fl += '||' + HESH_M[find_hesh(buf, TH)[1]].file + '\n';
            console.log(HESH_M[find_hesh(buf, TH)[1]].file);
            bb = HESH_M[find_hesh(buf, TH)[1]].file;
        }
        //console.log(fl);
        u_send(bb, TH_IP, 9);
        u_send(fl, TH_IP, ff);//ОТСЫЛАЕМ СОДЕЖИМОЕ
        fl_TH = false;
    }
    //А ВОТ И СОЕДЕРЖИМОЕ ФАЙЛА ПРИШЛО, СДЕЛАТЬ ИЗ НЕГО ФАЙЛ НУЖНО
    //*
    if (fl_f == true) {
        //name_of_file.split('.txt');  
        console.log(nm)
        fs.openSync('./files/' + nm, 'w');//СОЗДАЁМ ПУСТОЙ ФАЙЛ
        fs.writeFile('./files/' + nm, COM_F, function (error) {//ПИХАЕМ СОДЕРЖИМОЕ В ФАЙЛ
            if (error) throw error; 
        });
        fl_f = false;
    }
    //*/
    //ТЕСТОВЫЙ ПРОГОН СОДЕРЖИМОЕ ЛЕЖИТ В data.txt
    /*
    if (fl_f == true) {
        // name_of_file.split('.txt');
        fs.openSync('./files/data.txt', 'w');//СОЗДАЁМ ПУСТОЙ ФАЙЛ
        fs.writeFile('./files/data.txt', COM_F, function (error) {//ПИХАЕМ СОДЕРЖИМОЕ В ФАЙЛ
            if (error) throw error;
        });
        fl_f = false;
    }
    //*/
    //let fl = fs.readFileSync('./files/' + HESH_M[1].file, 'utf8');
    //console.log(fl);

    
    //*
    if (flag === true) {
        // Выводим информацию об online пользователях, которую сформировали с предыдущей рассылки.
        console.log("Online:");

        // Очищаем массив с информацией от соседей.
        while (onlineUser.length)
            console.log(onlineUser.pop());

        console.log("\n");

        console.log("Hesh:");
        // Очищаем массив с хэшами от файлов от соседей.
       // while (n_hesh.length) {
            //fs.appendFileSync("./files/data.txt", "||" + n_hesh[n_hesh.length - 1] + "|| \n", "UTF-8");
       //     console.log(n_hesh.pop().toString('hex'));
      //  }
    }
    else {
        console.log("Connection...");
        flag = true;
    }
    //*/
    // console.log("Request...");
    checkOnline(); // Запрос на проверку онлайн-пользователей.

    //весь бред ниже нужен для поиска адреса, на который нужно отослать хэш от файла.
    //сначала берём один из хэшей от файла.
    //затем, с помощю массива с хэшами от соседей (id) и хэша от файла создаём новый массив через опреацию XOR.
    //полученный массив переводим в 10 систему.
    //в 10-м массиве ищем индес минимального элемента - это индекс в массиве со всеми ip соседей.
    //заносим найденный индекс в массив-карту, который нужен для отправки хэшей по адресам.
    //в массиве-карте номер элемента массива это номер хэша от файла, а число в элементе массива это индекс в массиве ip.    
    //u_send('home_ip', home_ip, hash_ip);
    //ТЕСТОВЫЙ ПРОГОС ОТПРАВКИ СООБЩЕНИЙ С ХЭШАМИ ОТ ИМЕНИ ФАЙЛА
    for (let r = 0; r < allHesh.length; r++)
        u_send(allHesh[r], home_ip, mess);
    //console.log(home_ip.toString());
    if (alladdr.length != 0) {
        var i = 0;
        var send_map = []; // Массив со всеми номерами элементов allHesh, alladdr, allport для сборки сообщений с хэшами.
        send_map.length = allHesh.length;
        while (i < allHesh.length) {
            var buffID = [];
            var j = 0;
            while (j < allId.length) {
                buffID[j] = metric(allId[j], allHesh[i]);
                j++;
            }

            var find_buff = [];
            find_buff.length = allId.length;

            j = 0;
            while (j < allId.length) {
                find_buff[j] = roughScale(buffID[j].toString("hex"), 16).toString();
                j++;
            }
            //console.log(buffID);
            send_map[i] = arrayMin(find_buff);
            i++;
        }
        //console.log(send_map);
        for (var k = 0; k < send_map.length; k++) {
            send_hesh(home_ip, k); // хэш под номером k отправляем по адресу под номеров send_map[k]

            alladdr.splice(send_map[k], send_map[k]);
            if (allId.length > 1)
                allId.splice(send_map[k], send_map[k]);
        }
        //  console.log("\n");
    }
}

function send_hesh(ip, index) {
    var rmsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + allHesh[index].length); // Собираем сообщение, чтоб ппослать хэш
    rmsg[0] = mess;
    rmsg.fill(allHesh[index], msg_size, msg_size + allHesh[index].length)
    rmsg.writeUInt16BE(Buffer.byteLength(allHesh[index]), msg_size + allHesh[index].length);
    rmsg.fill(userName, msg_size + userId.length + msg_length_size); // + name
    dgramSocket.send(rmsg, 0, rmsg.length, port, ip);
}

function send_test(ip, type) {

    let fr = crypto.createHash('md5').update('f12').digest()// fs.readFileSync('./files/test.txt', 'utf8');
    var rmsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + fr.length); // Собираем сообщение, чтоб ппослать хэш
    rmsg[0] = type;
    rmsg.fill(fr, msg_size, msg_size + fr.length)
    rmsg.writeUInt16BE(Buffer.byteLength(fr), msg_size + fr.length);
    rmsg.fill(userName, msg_size + fr.length + msg_length_size); // + name
    dgramSocket.send(rmsg, 0, rmsg.length, port, ip);
}

function u_send(name, ip, type) {
    var rmsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + name.length); // Собираем сообщение, чтоб ппослать хэш
    rmsg[0] = type;
    rmsg.fill(name, msg_size, msg_size + name.length)
    rmsg.writeUInt16BE(Buffer.byteLength(userName), msg_size + name.length);
    rmsg.fill(userName, msg_size + name.length + msg_length_size); // + name
    dgramSocket.send(rmsg, 0, rmsg.length, port, ip);
}

// Функция широковещательной рассылки
function checkOnline() {
    var requestMsg = Buffer.allocUnsafe(msg_size + msg_length_size + Buffer.byteLength(userName) + userId.length); // Формируем сообщение для проверки пользователей
    requestMsg[0] = request;
    requestMsg.fill(userId, msg_size, msg_size + userId.length)
    requestMsg.writeUInt16BE(Buffer.byteLength(userName), msg_size + userId.length);
    requestMsg.fill(userName, msg_size + userId.length + msg_length_size); // + name
    dgramSocket.send(requestMsg, 0, requestMsg.length, port, ip_addr);// Отсылаем запрос
}